// alert("heyy ")
// window.alert("hello");

// var abc ="hello world";
// alert(abc);

// var b = 10;
// alert(b);

// var a =10;
// var b=20;
// var c= a+b;
// alert(c);

// alert("thanks for your input!");
// var name ="Badar";

// alert(name);

// var floogle = "badri";
// var name = "Badar";

// alert(floogle)

// var thanx = "hehehehe";
// alert(thanx);

// var weight =15;
// weight+25
// console.log(weight)

// var originalnum =12;
// var newnum=originalnum+7;
// console.log(newnum) 

// var originalNum = 23;
// var numToBeAdded = 7;
// var newNum = originalNum + numToBeAdded;
// console.log(newNum)

// var caseQty = 144;
// alert(caseQty);

// var num = 2 + 2;
// alert(num)

// var a= 8+10;
// var b=3*5;
// var c=10/2;
// alert(c) 

// var num = 1;
// var newNum = ++num;
// console.log(newNum)

// var num= 5;
// var newnum=num--;
// console.log(newnum) 

// var num= 5;
// var newnum=--num;
// console.log(newnum)

// var totalCost = 1 + (3 * 4);
// var resultOfComputation = (2 * 4) * 4 + 2;
// console.log(resultOfComputation)

// var resultOfComputation = ((5 * 4) * 9) + 2;
// console.log(resultOfComputation)


// var message = "Thanks, ";
// var name ="Badar";
// var banger = "!";
// alert(message + name+ banger);

var message = "Thanks, ";
var userName = "Badar";
 var banger = "!";
 var customMess = message + userName + banger;
 alert(customMess);